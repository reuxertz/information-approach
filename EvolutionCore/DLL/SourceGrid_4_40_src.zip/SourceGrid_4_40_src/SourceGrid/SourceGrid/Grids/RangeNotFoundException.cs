﻿using System;

namespace SourceGrid
{
	public class RangeNotFoundException: Exception
	{
		
	}
}
