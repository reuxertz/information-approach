﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace EvolutionTools
{
    public class LocalBlast
    {
        public enum BlastType { Protein, Nucleotide };
        public static string[] BlastCommands = new string[] { "blastp", "blastn" };

        protected string _NCBIBlasteEXEPath;
        protected string _localFastaPath;
        protected string _localDBPath;
        protected string _outputPath;

        public LocalBlast(string ncbiPath, string fastaPath, string localDBPath, string outputPath)
        {
            if (Directory.Exists(ncbiPath))
                this._NCBIBlasteEXEPath = ncbiPath;
            if (Directory.Exists(fastaPath))
                this._localFastaPath = fastaPath;
            if (Directory.Exists(localDBPath))
                this._localDBPath = localDBPath;
            if (Directory.Exists(outputPath))
                this._localDBPath = outputPath;

            //Create new Database through c# command line simulator/wrapper. Wait for completion

        }

        public void CreateLocalBlastDatabse(RunCommand command)
        {       
            //Name for local db
            if (this._localDBPath.EndsWith(@"\"))
                this._localDBPath += @"\";
            var outFilePath = this._localDBPath + @"~tempLocalBlastDB";

            //Check for part of db, if exists, remove to force new db creation
            if (File.Exists(outFilePath + ".pin"))
                File.Delete(outFilePath + ".pin");

            //Create new Database through c# command line simulator/wrapper. Wait for completion
            command.RunCommandLine("makeblastdb -in " + this._localFastaPath + " -dbtype prot -out " + outFilePath, this._NCBIBlasteEXEPath);
        }
        public void PerformBlast(RunCommand command, BlastType bp, string queryPath)
        {
            command.RunCommandLine(LocalBlast.BlastCommands[(int)bp] +
                    @" -db " + this._localDBPath + //"C:\Ryan\ProteinProj\ProjectFiles\~tempLocalBlastDB " + 
                    @" -query " + queryPath + //" C:\Ryan\ProteinProj\ProjectFiles\tempLocalBlastQuery.txt " + 
                    @" -out " + _outputPath, this._NCBIBlasteEXEPath); //C:\Ryan\ProteinProj\ProjectFiles\~tempLocalBlast.txt", NCBIExs);
        }



    }
} 
